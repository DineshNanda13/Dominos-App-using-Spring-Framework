package com.dominosMontreal;

public interface Discounts {
	
	public String getDiscounts();
}
