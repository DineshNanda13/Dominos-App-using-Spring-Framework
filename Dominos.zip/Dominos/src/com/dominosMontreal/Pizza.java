package com.dominosMontreal;

public interface Pizza {
	
	public String getPizza();
	
	public String getDailyDeals();

}
