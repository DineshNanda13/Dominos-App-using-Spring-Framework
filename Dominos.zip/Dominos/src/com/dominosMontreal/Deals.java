package com.dominosMontreal;

public class Deals implements Discounts {

	@Override
	public String getDiscounts() {
		return "10% off on your selected pizza!";
	}

}
